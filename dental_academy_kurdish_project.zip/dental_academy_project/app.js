// 1) Put your Supabase Project URL and anon/publishable key below.
// Never put a Supabase service_role/secret key in browser code.
const SUPABASE_URL = ""; // e.g. https://your-project.supabase.co
const SUPABASE_ANON_KEY = ""; // publishable/anon key only
const MAX_FILE_BYTES = 4 * 1024 * 1024;
const ALLOWED_TYPES = ["image/jpeg","image/png","image/webp","application/pdf"];

// Edit this list with real event titles, dates, prices and locations.
const EVENTS = [
  {title:"کۆرسی زانستی ددانپزیشکی", date:"بەروار دیاری دەکرێت", place:"شوێن دیاری دەکرێت", description:"کۆرسێک بۆ نوێکردنەوەی زانیاری و پەرەپێدانی تواناکانی کلینیکی."},
  {title:"کۆنفرانسی ددانپزیشکی", date:"بەروار دیاری دەکرێت", place:"شوێن دیاری دەکرێت", description:"بەشداری لە گفتوگۆی زانستی و ناسینی ڕێکارە نوێکانی بواری ددانپزیشکی."}
];
const $ = id => document.getElementById(id);
const client = SUPABASE_URL && SUPABASE_ANON_KEY && window.supabase
  ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

function renderEvents(){
  $("courses").innerHTML = EVENTS.map(e => `<article class="course"><div style="display:flex;justify-content:space-between;gap:10px;align-items:start"><h3>${escapeHtml(e.title)}</h3><span class="tag">تۆمارکردن</span></div><p>${escapeHtml(e.description)}</p><div class="meta"><span>◷ ${escapeHtml(e.date)}</span><span>⌖ ${escapeHtml(e.place)}</span></div></article>`).join("");
  for(const e of EVENTS){const o=document.createElement("option");o.value=e.title;o.textContent=e.title;$("event").appendChild(o);}
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function showResult(message,error=false){const box=$("result");box.className="result"+(error?" error":"");box.textContent=message;box.style.display="block";box.scrollIntoView({behavior:"smooth",block:"nearest"});}
renderEvents();
if(client){$("setupNotice").textContent="سیستەمی تۆمارکردن ڕێکخراوە. داواکارییەکان بە پێی ڕێکخستنی داتابەیس دەنێردرێن.";}

$("regForm").addEventListener("submit",async e=>{
  e.preventDefault();
  if(!client){showResult("هێشتا داتابەیس ڕێک نەخراوە. ڕێنمایی README.md بخوێنەوە و Supabase URL و publishable key زیاد بکە.",true);return;}
  const file=$("receipt").files[0];
  if(file && !ALLOWED_TYPES.includes(file.type)){showResult("جۆری فایل پشتگیری ناکرێت. JPG، PNG، WEBP یان PDF هەڵبژێرە.",true);return;}
  if(file && file.size>MAX_FILE_BYTES){showResult("قەبارەی فایل نابێت لە 4MB زیاتر بێت.",true);return;}
  const btn=$("submitBtn");btn.disabled=true;btn.textContent="تکایە چاوەڕێ بکە...";
  try{
    const payload={
      full_name:$("fullname").value.trim(),
      phone:$("phone").value.trim(),
      email:$("email").value.trim()||null,
      city:$("city").value.trim()||null,
      event_title:$("event").value,
      payment_method:$("payment").value,
      payment_status:"pending"
    };
    const {data,error}=await client.from("registrations").insert(payload).select("id,tracking_code").single();
    if(error) throw error;
    if(file){
      const safeName=file.name.replace(/[^a-zA-Z0-9._-]/g,"_").slice(-100);
      const path=`${data.id}/${Date.now()}-${safeName}`;
      const up=await client.storage.from("receipts").upload(path,file,{upsert:false,contentType:file.type});
      if(up.error){
        showResult(`تۆمارکردن کرا، بەڵام بارکردنی وەسڵ سەرکەوتوو نەبوو. کۆدی تۆمار: ${data.tracking_code}. تکایە پەیوەندی بە بەڕێوەبەرەوە بکە.`,true);
      }else{
        const {error:updateError}=await client.from("registrations").update({receipt_path:path}).eq("id",data.id);
        if(updateError) showResult(`تۆمارکردن کرا. کۆد: ${data.tracking_code}. بارکردنی وەسڵ کرا، بەڵام بەڕێوەبردنی وەسڵ پێویستی بە پشکنین هەیە.`,true);
        else showResult(`داواکارییەکەت بە سەرکەوتوویی نێردرا. کۆدی بەدواداچوون: ${data.tracking_code}. پارەدان هێشتا پشتڕاست نەکراوەتەوە.`);
      }
    }else showResult(`داواکارییەکەت بە سەرکەوتوویی نێردرا. کۆدی بەدواداچوون: ${data.tracking_code}. پارەدان هێشتا پشتڕاست نەکراوەتەوە.`);
    $("regForm").reset();
  }catch(err){
    console.error(err);
    showResult("ناردنی داواکاری سەرکەوتوو نەبوو. ڕێکخستنی داتابەیس و policy ـەکان بپشکنە و دووبارە هەوڵ بدەرەوە.",true);
  }finally{btn.disabled=false;btn.textContent="ناردنی داواکاری";}
});