-- Supabase SQL Editor: run this script after creating a project.
-- Public users can submit registrations; only authenticated users with app_metadata.role = 'admin'
-- can read or update registrations. Never expose a service_role key in frontend code.

create extension if not exists pgcrypto;

create table if not exists public.registrations (
  id uuid primary key default gen_random_uuid(),
  tracking_code text not null unique default (
    'DA-' || to_char(now(), 'YYYY') || '-' || upper(substr(encode(gen_random_bytes(5),'hex'),1,8))
  ),
  full_name text not null check (char_length(full_name) between 2 and 120),
  phone text not null check (char_length(phone) between 5 and 40),
  email text check (email is null or char_length(email) <= 160),
  city text check (city is null or char_length(city) <= 160),
  event_title text not null check (char_length(event_title) between 2 and 200),
  payment_method text not null check (payment_method in ('FIB','cash')),
  payment_status text not null default 'pending' check (payment_status in ('pending','confirmed','rejected')),
  receipt_path text,
  created_at timestamptz not null default now()
);

alter table public.registrations enable row level security;

drop policy if exists "Public can submit registration" on public.registrations;
create policy "Public can submit registration"
on public.registrations for insert to anon, authenticated
with check (
  char_length(full_name) between 2 and 120
  and char_length(phone) between 5 and 40
  and payment_method in ('FIB','cash')
  and payment_status = 'pending'
);

drop policy if exists "Admins can read registrations" on public.registrations;
create policy "Admins can read registrations"
on public.registrations for select to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "Admins can update registrations" on public.registrations;
create policy "Admins can update registrations"
on public.registrations for update to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- Create a PRIVATE storage bucket named "receipts" in Supabase Storage.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('receipts','receipts',false,4194304,array['image/jpeg','image/png','image/webp','application/pdf'])
on conflict (id) do update set public=false, file_size_limit=4194304,
allowed_mime_types=array['image/jpeg','image/png','image/webp','application/pdf'];

-- Anonymous participants can upload receipt files under a folder named after registration UUID.
-- Read/delete access is admin-only. Review these policies and test before public launch.
drop policy if exists "Participants upload receipts" on storage.objects;
create policy "Participants upload receipts" on storage.objects
for insert to anon, authenticated
with check (
  bucket_id = 'receipts'
  and (storage.foldername(name))[1] ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
);

drop policy if exists "Admins read receipts" on storage.objects;
create policy "Admins read receipts" on storage.objects
for select to authenticated
using (bucket_id='receipts' and (auth.jwt() -> 'app_metadata' ->> 'role')='admin');

drop policy if exists "Admins delete receipts" on storage.objects;
create policy "Admins delete receipts" on storage.objects
for delete to authenticated
using (bucket_id='receipts' and (auth.jwt() -> 'app_metadata' ->> 'role')='admin');

-- IMPORTANT: Admins must be created securely through Supabase Auth and have app_metadata.role = 'admin'
-- set server-side by a trusted administrator. Never let public users set their own role.
